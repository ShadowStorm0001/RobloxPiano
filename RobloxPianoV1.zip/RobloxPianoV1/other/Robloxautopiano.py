import tkinter as tk
import time
import threading
from pynput.keyboard import Controller, Key
import keyboard  # For listening to the F6 key

# Global variable to control replay
is_replaying = False

# Initialize the keyboard controller
keyboard_controller = Controller()

def type_notes(notes):
    for note in notes.split():
        if not is_replaying:  # Stop if the user has pressed F6 to stop
            break
        if note.startswith('[') and note.endswith(']'):
            # Play simultaneous notes (type all letters together)
            simultaneous_notes = note[1:-1]
            for n in simultaneous_notes:
                keyboard_controller.press(n)
                keyboard_controller.release(n)
            print(f"Typed notes together: {simultaneous_notes}")
        else:
            # Play single note (type a single letter)
            keyboard_controller.press(note)
            keyboard_controller.release(note)
            print(f"Typed note: {note}")
        
        # Delay between notes
        time.sleep(delay / 1000)  # Convert milliseconds to seconds

def start_playing(continuous=False):
    global is_replaying
    notes = input_box.get("1.0", "end-1c")
    try:
        global delay
        delay = int(delay_box.get())
    except ValueError:
        delay = 0  # Default to no delay if invalid input

    def replay():
        global is_replaying
        while is_replaying:
            type_notes(notes)
            if not continuous:  # If not in continuous mode, stop after one replay
                break

    # Use threading to avoid blocking the GUI while typing notes
    is_replaying = True
    play_thread = threading.Thread(target=replay)
    play_thread.start()

def toggle_replay():
    global is_replaying
    if is_replaying:
        is_replaying = False
        print("Replay stopped")
    else:
        is_replaying = True
        print("Replay started")
        start_playing(continuous=True)

# Setup F6 key binding to stop/start replay
def listen_f6_key():
    keyboard.add_hotkey('F6', toggle_replay)

listen_f6_key_thread = threading.Thread(target=listen_f6_key)
listen_f6_key_thread.daemon = True
listen_f6_key_thread.start()

# Setup the GUI
root = tk.Tk()
root.title("Sheet Music Player")

# Input box for sheet music
input_label = tk.Label(root, text="Enter sheet music:")
input_label.pack()

input_box = tk.Text(root, height=10, width=40)
input_box.pack()

# Delay box for setting delay between notes
delay_label = tk.Label(root, text="Enter delay (ms) between notes:")
delay_label.pack()

delay_box = tk.Entry(root)
delay_box.pack()

# Play button (single play)
play_button = tk.Button(root, text="Play Once", command=lambda: start_playing(continuous=False))
play_button.pack()

# Continuous replay button
continuous_button = tk.Button(root, text="Continuous Replay", command=lambda: start_playing(continuous=True))
continuous_button.pack()

root.mainloop()
